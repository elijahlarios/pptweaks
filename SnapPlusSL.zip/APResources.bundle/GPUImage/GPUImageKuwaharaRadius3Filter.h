//
//  GPUImageKuwaharaRadius3Filter.h

#import "GPUImageFilter.h"

@interface GPUImageKuwaharaRadius3Filter : GPUImageFilter

@end
