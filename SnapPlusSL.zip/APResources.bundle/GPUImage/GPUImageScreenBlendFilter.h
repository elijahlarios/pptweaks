#import "GPUImageTwoInputFilter.h"

@interface GPUImageScreenBlendFilter : GPUImageTwoInputFilter
{
}

@end
