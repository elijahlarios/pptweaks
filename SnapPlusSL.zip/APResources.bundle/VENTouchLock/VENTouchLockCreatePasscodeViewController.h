#import "VENTouchLockPasscodeViewController.h"

@interface VENTouchLockCreatePasscodeViewController : VENTouchLockPasscodeViewController

@end
