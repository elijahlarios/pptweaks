#import "VENTouchLockPasscodeViewController.h"

@interface VENTouchLockEnterPasscodeViewController : VENTouchLockPasscodeViewController

/**
 Resets the number of passcode attempts recorded to 0
 */
+ (void)resetPasscodeAttemptHistory;

@end